require("dotenv").config();
const app=require("./app"); const pool=require("./config/db");
const PORT=process.env.PORT||5000;
pool.query("SELECT 1").then(()=>app.listen(PORT,()=>console.log(`StudyFlow API running on http://localhost:${PORT}`))).catch(e=>{console.error(e.message);process.exit(1)});