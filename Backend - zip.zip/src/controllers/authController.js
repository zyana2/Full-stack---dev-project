const bcrypt=require("bcryptjs"),jwt=require("jsonwebtoken"),pool=require("../config/db");
const {registerErrors}=require("../utils/validation");
const token=u=>jwt.sign({id:u.id,email:u.email},process.env.JWT_SECRET,{expiresIn:process.env.JWT_EXPIRES_IN||"1d"});
async function register(req,res,next){try{
 const errors=registerErrors(req.body);if(errors.length)return res.status(400).json({success:false,errors});
 const {name,password}=req.body,email=req.body.email.trim().toLowerCase();
 const [exists]=await pool.query("SELECT id FROM users WHERE email=?",[email]);
 if(exists.length)return res.status(409).json({success:false,message:"Email is already registered"});
 const hash=await bcrypt.hash(password,12);
 const [r]=await pool.query("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",[name.trim(),email,hash]);
 const user={id:r.insertId,name:name.trim(),email};
 res.status(201).json({success:true,message:"Account created successfully",user,token:token(user)});
}catch(e){next(e)}}
async function login(req,res,next){try{
 const {email,password}=req.body;if(!email||!password)return res.status(400).json({success:false,message:"Email and password are required"});
 const [rows]=await pool.query("SELECT id,name,email,password_hash FROM users WHERE email=?",[email.trim().toLowerCase()]);
 if(!rows.length||!(await bcrypt.compare(password,rows[0].password_hash)))return res.status(401).json({success:false,message:"Invalid email or password"});
 const u=rows[0],user={id:u.id,name:u.name,email:u.email};
 res.json({success:true,message:"Login successful",user,token:token(user)});
}catch(e){next(e)}}
module.exports={register,login};