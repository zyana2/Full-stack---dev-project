const pool=require("../config/db");
async function getDashboard(req,res,next){try{
 const [[s]]=await pool.query("SELECT COUNT(*) total_tasks,SUM(status='completed') completed_tasks,SUM(status='pending') pending_tasks,SUM(due_date=CURDATE() AND status='pending') today_pending FROM tasks WHERE user_id=?",[req.user.id]);
 const [tasks]=await pool.query("SELECT id,title,due_date,priority,status FROM tasks WHERE user_id=? ORDER BY due_date IS NULL,due_date ASC LIMIT 5",[req.user.id]);
 res.json({success:true,stats:{total_tasks:Number(s.total_tasks||0),completed_tasks:Number(s.completed_tasks||0),pending_tasks:Number(s.pending_tasks||0),today_pending:Number(s.today_pending||0)},recent_tasks:tasks});
}catch(e){next(e)}}
module.exports={getDashboard};