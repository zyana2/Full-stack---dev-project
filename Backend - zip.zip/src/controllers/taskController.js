const pool=require("../config/db");const {taskErrors}=require("../utils/validation");
async function getTasks(req,res,next){try{
 let sql="SELECT t.*,c.name category_name FROM tasks t LEFT JOIN categories c ON c.id=t.category_id WHERE t.user_id=?";
 let p=[req.user.id];if(req.query.status){sql+=" AND t.status=?";p.push(req.query.status)}if(req.query.priority){sql+=" AND t.priority=?";p.push(req.query.priority)}
 if(req.query.search){sql+=" AND (t.title LIKE ? OR t.description LIKE ?)";let s="%"+req.query.search+"%";p.push(s,s)}
 sql+=" ORDER BY t.due_date IS NULL,t.due_date ASC,t.created_at DESC";const [rows]=await pool.query(sql,p);
 res.json({success:true,count:rows.length,tasks:rows});}catch(e){next(e)}}
async function getTask(req,res,next){try{const [r]=await pool.query("SELECT * FROM tasks WHERE id=? AND user_id=?",[req.params.id,req.user.id]);if(!r.length)return res.status(404).json({success:false,message:"Task not found"});res.json({success:true,task:r[0]})}catch(e){next(e)}}
async function createTask(req,res,next){try{
 const e=taskErrors(req.body);if(e.length)return res.status(400).json({success:false,errors:e});
 const {title,description=null,due_date=null,priority="medium",status="pending",category_id=null}=req.body;
 const [r]=await pool.query("INSERT INTO tasks(user_id,category_id,title,description,due_date,priority,status) VALUES(?,?,?,?,?,?,?)",[req.user.id,category_id,title.trim(),description,due_date,priority,status]);
 res.status(201).json({success:true,message:"Task created successfully",taskId:r.insertId});}catch(e){next(e)}}
async function updateTask(req,res,next){try{
 const [old]=await pool.query("SELECT * FROM tasks WHERE id=? AND user_id=?",[req.params.id,req.user.id]);if(!old.length)return res.status(404).json({success:false,message:"Task not found"});
 const o=old[0],b={...o,...req.body};const e=taskErrors(b);if(e.length)return res.status(400).json({success:false,errors:e});
 await pool.query("UPDATE tasks SET title=?,description=?,due_date=?,priority=?,status=?,category_id=? WHERE id=? AND user_id=?",[b.title.trim(),b.description,b.due_date,b.priority,b.status,b.category_id,req.params.id,req.user.id]);
 res.json({success:true,message:"Task updated successfully"});}catch(e){next(e)}}
async function deleteTask(req,res,next){try{const [r]=await pool.query("DELETE FROM tasks WHERE id=? AND user_id=?",[req.params.id,req.user.id]);if(!r.affectedRows)return res.status(404).json({success:false,message:"Task not found"});res.json({success:true,message:"Task deleted successfully"})}catch(e){next(e)}}
module.exports={getTasks,getTask,createTask,updateTask,deleteTask};