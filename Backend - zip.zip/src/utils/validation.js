function taskErrors(b){
 const e=[];
 if(!b.title||typeof b.title!=="string"||!b.title.trim()) e.push("Title is required");
 if(b.title&&b.title.trim().length>150)e.push("Title must be 150 characters or fewer");
 if(b.priority&&!["low","medium","high"].includes(b.priority))e.push("Priority must be low, medium, or high");
 if(b.status&&!["pending","completed"].includes(b.status))e.push("Status must be pending or completed");
 return e;
}
function registerErrors(b){
 const e=[];
 if(!b.name?.trim())e.push("Name is required");
 if(!b.email?.trim())e.push("Email is required");
 if(!b.password||b.password.length<6)e.push("Password must contain at least 6 characters");
 if(b.email&&!/^\S+@\S+\.\S+$/.test(b.email))e.push("A valid email is required");
 return e;
}
module.exports={taskErrors,registerErrors};