# StudyFlow API Documentation

Base URL: `http://localhost:5000/api`

Protected endpoints require `Authorization: Bearer <JWT_TOKEN>`.

## Health
### GET `/health`
No authentication.
Response 200:
`{"success":true,"message":"StudyFlow API is running"}`

## Authentication
### POST `/auth/register`
Body:
`{"name":"Ali Student","email":"ali@example.com","password":"secret123"}`
Returns 201 with user and JWT token.
Errors: 400 validation, 409 duplicate email.

### POST `/auth/login`
Body:
`{"email":"ali@example.com","password":"secret123"}`
Returns 200 with user and JWT token.
Errors: 400 missing credentials, 401 invalid credentials.

## Tasks
### GET `/tasks`
Protected. Optional query parameters: `status`, `priority`, `search`.
Returns the authenticated user's tasks.

### GET `/tasks/:id`
Protected. Returns one owned task. 404 if not found.

### POST `/tasks`
Protected. Body:
`{"title":"DSA Assignment","description":"Practice linked lists","due_date":"2026-09-01","priority":"high","status":"pending","category_id":1}`
Required: title. Priority: low/medium/high. Status: pending/completed.
Returns 201.

### PUT `/tasks/:id`
Protected. Updates an owned task. Same task fields may be supplied.
Returns 200.

### DELETE `/tasks/:id`
Protected. Deletes an owned task. Returns 200.

## Categories
### GET `/categories`
Protected. Returns the user's categories.

### POST `/categories`
Protected. Body: `{"name":"University"}`. Returns 201.

## Dashboard
### GET `/dashboard`
Protected. Returns total, completed, pending and today's pending task counts plus five recent tasks.

## Status Codes
200 Success; 201 Created; 400 Bad Request; 401 Unauthorized; 404 Not Found; 409 Conflict; 500 Server Error.

## Example error
`{"success":false,"message":"Task not found"}`

## Data Ownership
All task/category queries use the authenticated user ID so users can only access their own data.
