# StudyFlow — Week 3 Back-End API

## Overview
StudyFlow is a student task and study planner. Week 3 adds the server-side REST API, MySQL database interaction, JWT authentication, CRUD operations, validation and error handling.

## Technologies
Node.js, Express.js, MySQL, JWT, bcryptjs, Jest and Supertest.

## Setup
1. Install Node.js 18+ and MySQL 8+.
2. Run `npm install`.
3. Run `database/schema.sql` in MySQL.
4. Copy `.env.example` to `.env` and enter your MySQL credentials and a JWT secret.
5. Run `npm run dev`.
6. API base URL: `http://localhost:5000/api`.

## Commands
`npm run dev` — development server
`npm start` — start server
`npm test` — run tests

## Authentication
Register/login returns a JWT. Protected requests use:
`Authorization: Bearer YOUR_TOKEN`

## Features
- Register and login
- Hashed passwords
- JWT-protected routes
- Task CRUD
- Task filtering/search
- Categories
- Dashboard statistics
- Validation and HTTP error responses
- User data ownership checks
- Basic automated tests

## Security
Passwords are hashed with bcrypt. SQL queries use parameters. JWT secrets and database credentials are stored in environment variables and `.env` is ignored by Git.

See `API_DOCUMENTATION.md` for all endpoints and examples.

## Author
Student: ____________________