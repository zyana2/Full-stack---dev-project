StudyFlow Week 5

Run: npm install && npm test. Includes testing strategy, manual checklist, debugging logs and optimization notes.
