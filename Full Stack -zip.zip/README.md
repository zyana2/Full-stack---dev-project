# StudyFlow — Week 4 Full Stack Integration

This deliverable combines the StudyFlow frontend and backend into one full-stack application.

## Architecture
Browser UI → JavaScript Fetch API → Express REST API → MySQL

## Integration
The frontend uses asynchronous `fetch()` requests to the backend. JWT authentication is stored in localStorage and automatically attached to protected requests. CRUD actions refresh the dashboard/task data so the UI stays synchronized with the database.

## Run
1. Start MySQL and execute `backend/database/schema.sql`.
2. Open `backend`, run `npm install`, create `.env` from `.env.example`, then run `npm run dev`.
3. Open `frontend/index.html` with VS Code Live Server.
4. Register/login and test task creation, completion and deletion.

## Main integration endpoints
POST /api/auth/register
POST /api/auth/login
GET /api/tasks
POST /api/tasks
PUT /api/tasks/:id
DELETE /api/tasks/:id
GET /api/dashboard

## Challenges addressed
CORS was enabled for frontend-backend communication; JWT is attached to protected requests; API errors are shown to the user; database changes trigger frontend refreshes.
