# StudyFlow Week 4 — Full Stack Integration
Frontend and backend are integrated through REST APIs.

## Run Backend
cd backend
npm install
copy .env.example to .env
Create the MySQL database by running database/schema.sql
npm run dev

Backend: http://localhost:5000

## Run Frontend
Open frontend/index.html with VS Code Live Server, or run any local static server.

The frontend calls:
POST /api/auth/register
POST /api/auth/login
GET /api/tasks
POST /api/tasks
PUT /api/tasks/:id
DELETE /api/tasks/:id
GET /api/dashboard

JWT is stored in browser localStorage and sent as a Bearer token.
